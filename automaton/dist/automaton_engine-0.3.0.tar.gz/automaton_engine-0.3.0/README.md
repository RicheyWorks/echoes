# automaton  (v0.2.0)

A strongly consistent personal automation platform.

Triggers fire workflows. Workflows are a DAG of steps. Every step's *observable* side effect happens exactly once, even when workers crash mid-step. State lives in a single SQLite database — back that one file up and you've backed up the system.

See the design rationale and trade-offs in [`../automation-system-design.md`](../automation-system-design.md). For deployment-day prep see [LIVE-TEST-READINESS.md](LIVE-TEST-READINESS.md). For backup strategy see [BACKUP.md](BACKUP.md).

## Install

```bash
cd automaton
pip install -e .
```

Requires Python 3.10+. Pulls in `pyyaml`, `httpx`, and `croniter`.

## End-to-end example

Define a workflow as YAML — a name and a list of steps. Each step has a type, optional `needs:` for dependencies, an optional `retry:` policy, and type-specific fields:

```yaml
# examples/hello.yaml
name: hello
steps:
  - name: greet
    type: file_append
    path: /tmp/automaton-hello.log
    text: "hello from automaton"
  - name: again
    type: file_append
    needs: [greet]
    path: /tmp/automaton-hello.log
    text: "step two ran after step one"
```

Register it, trigger a run, drain the queue:

```bash
automaton register examples/hello.yaml
automaton trigger hello
automaton worker --once       # processes everything, then exits
automaton inspect             # see the run
```

Or set it on a schedule and leave a scheduler + worker + UI running:

```bash
automaton schedule add hello '*/5 * * * *'
automaton scheduler &         # one process: fires due crons
automaton worker &            # one or more processes: drains the queue
automaton serve               # http://127.0.0.1:8080 - live dashboard
```

## CLI reference

| Command | Purpose |
|---|---|
| `automaton register FILE.yaml` | Register / update a workflow definition (versioned per name). |
| `automaton trigger NAME [--payload JSON]` | Manually trigger a run. |
| `automaton worker [--once]` | Run the worker loop. `--once` stops when the queue is empty. |
| `automaton inspect [RUN_ID]` | List recent runs, or print one run's full detail as JSON. |
| `automaton schedule add NAME EXPR [--timezone TZ]` | Register a cron trigger (5-field expression). `TZ` is an IANA name; default UTC. Idempotent. |
| `automaton schedule list` | List cron triggers with next/last fire times. |
| `automaton scheduler [--stop-after S]` | Run the scheduler leader loop. |
| `automaton scheduler next EXPR [--timezone TZ] [--count N]` | Preview the next N fire times for a cron expression (DST debug). |
| `automaton serve [--host H] [--port N] [--insecure-no-auth]` | Run the inspection UI + write API. |
| `automaton signal RUN_ID NAME [--payload JSON]` | Send a signal to a parked workflow. |
| `automaton cancel RUN_ID [--reason TEXT]` | Cancel an in-flight run. |
| `automaton webhook add NAME --workflow NAME` | Register a signed webhook endpoint; prints its secret. |
| `automaton webhook list` / `disable NAME` | Manage webhook endpoints. |
| `automaton prune [--older-than DAYS] [--dry-run] [--vacuum]` | Delete terminal runs older than the threshold. |
| `automaton backup DEST` | Online snapshot of the live DB to a file (with `PRAGMA integrity_check`). |
| `automaton restore SRC [--force]` | Restore the live DB from a snapshot; verifies integrity + schema. |
| `automaton init NAME --template SLUG` | Copy a built-in workflow template into the current directory. `automaton init --list` shows the catalog. |

DB location: `./automaton.db` by default; override with `AUTOMATON_DB`.

## HTTP API (for agents and integrations)

`automaton serve` exposes both read and write routes. Read routes are open; write routes require `Authorization: Bearer $AUTOMATON_TOKEN` unless you pass `--insecure-no-auth`.

**Read**
- `GET /api/runs` - list recent runs
- `GET /api/run/<id>` - one run's full detail (steps, events)
- `GET /api/crons` - list cron triggers
- `GET /api/step_types` - list registered step types (built-in + plugins)
- `GET /healthz` - liveness check

**Write** (require token)
- `POST /api/workflows` - body: workflow YAML or JSON spec - returns `{workflow_def_id}`
- `POST /api/trigger/<name>` - body: optional `{"payload": ...}` - returns `{run_id}`
- `POST /api/crons` - body: `{"workflow_name", "cron_expr"}` - returns `{trigger_id}`
- `POST /api/signals/<run_id>/<name>` - body: optional `{"payload": ...}` - returns `{signal_id}`
- `POST /api/run/<id>/cancel` - body: optional `{"reason": ...}` - returns `{cancelled: true, run_id}`

Plus `GET /api/signals` to list recent signals and `GET /api/webhooks` to list webhook endpoints (read routes, no auth).

**Webhook receiver** (separate auth: per-endpoint HMAC signature, not bearer token)
- `POST /webhook/<name>` - body: any JSON; signature in `X-Automaton-Signature` header (configurable per endpoint)

Example (agent triggering a run):

```bash
curl -X POST http://127.0.0.1:8080/api/trigger/hello \
  -H "Authorization: Bearer $AUTOMATON_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"payload": {"caller": "my-agent"}}'
```

## Step types

| Type | Fields | Notes |
|---|---|---|
| `http_get` | `url`, optional `headers`, `timeout` | Sends `Idempotency-Key` header. |
| `file_append` | `path`, `text` | Self-deduplicating; idempotency key serves as the dedupe marker. |
| `wait_for_signal` | `signal`, optional `poll_seconds`, `timeout_seconds` | Parks the run until a signal arrives. See [Signals](#signals) below. |
| `http` | `method`, `url`, optional `headers`, `body`, `timeout` | Any HTTP verb. JSON body if dict/list; raw string otherwise. |
| `shell` | `cmd` (list or string), optional `cwd`, `env`, `timeout`, `ok_returncodes` | Subprocess. Captures stdout/stderr/returncode. Use only with idempotent commands. |

### Adding a step type in-tree

```python
from automaton.steps import step_type, StepError

@step_type("my_step")
def my_step(spec, idempotency_key):
    # spec is the dict from the workflow YAML for this step
    # idempotency_key is a stable sha256 hash per (run, step_name, attempt)
    return {"output": "..."}    # JSON-serializable
```

### Adding a step type from an external package (plugin)

Declare an entry point in your package's `pyproject.toml`:

```toml
[project.entry-points."automaton.step_types"]
slack_post = "my_agent.slack_step"
```

The module `my_agent.slack_step` should call `@step_type(...)` at import time. Once your package is installed, the worker discovers it automatically. Broken plugins fail loudly in the log but don't take down the worker.

## Workflow validation

Workflows are validated at `register` time, not just at first run. Catches:

- missing `name` or `steps`
- a step missing `name` or `type`
- duplicate step names
- `needs:` references to nonexistent steps
- cycles in the DAG

So `automaton register wf.yaml` either succeeds (the spec is in the DB and addressable) or refuses with a clear error. No half-broken workflows that explode on first trigger.

## Step output references

A step can pull data from earlier steps' outputs (and from the run's trigger payload) via `${{ ... }}` templates. The engine resolves these in the step's spec before handing it to the step type.

```yaml
name: fetch_and_notify
steps:
  - name: fetch
    type: http
    method: GET
    url: "https://api.example.com/users/${{ run.payload.user_id }}"
  - name: notify
    type: http
    needs: [fetch]
    method: POST
    url: https://hooks.example.com/notify
    headers:
      Content-Type: application/json
    body:
      user: "${{ steps.fetch.output.body }}"
      run_id: "${{ run.id }}"
```

Resolvable paths: `run.id`, `run.payload[.PATH]`, `steps.<NAME>.output[.PATH]`, `steps.<NAME>.status`. Paths are dot-separated; integers index into lists. A whole-string template (`"${{ run.id }}"`) returns the resolved value with its original type (int/dict/etc); a template embedded in surrounding text (`"run-${{ run.id }}-done"`) is stringified. Missing paths fail the step as `TemplateError` — retry policy applies as usual.

## Signals

For human-in-the-loop and agent-in-the-loop workflows. A `wait_for_signal` step parks the run until a named signal arrives, then completes with the signal's payload as its output. Subsequent steps see that payload via the run's step history.

```yaml
name: agent_loop
steps:
  - name: kickoff
    type: file_append
    path: /tmp/agent.log
    text: "waiting on agent..."
  - name: wait_for_agent
    type: wait_for_signal
    needs: [kickoff]
    signal: agent_response       # unique name within this run
    poll_seconds: 1              # how often the worker re-checks
    timeout_seconds: 3600        # give up after this long
```

The worker parks the step on each poll (releases the lease, sets a future `ready_at`, status reverts to `pending`). Send the signal from a CLI or API:

```bash
# CLI
automaton signal 42 agent_response --payload '{"answer": 42}'

# HTTP (for agents)
curl -X POST http://127.0.0.1:8080/api/signals/42/agent_response \
  -H "Authorization: Bearer $AUTOMATON_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"payload": {"answer": 42}}'
```

Signals are durable: send before or after the step starts waiting — the step picks up the first unconsumed match. Each signal is consumed exactly once.

## Webhooks (inbound, signed)

For integrations where the *upstream* calls you — GitHub, Stripe, Twilio, your own agents using their own credentials. Each webhook endpoint has its own HMAC secret; requests are verified per-endpoint, not against the shared `AUTOMATON_TOKEN`.

```bash
# Register an endpoint. Prints a secret ONCE - store it for the upstream.
automaton webhook add gh-push --workflow hello

# List configured endpoints (secrets are never shown again).
automaton webhook list

# Disable an endpoint without deleting it.
automaton webhook disable gh-push
```

The upstream posts to `POST /webhook/<name>` with an HMAC signature header. Default header is `X-Automaton-Signature`, default algo is sha256, both configurable per endpoint. Format: `sha256=<hex>` (a bare hex value is also accepted as a fallback). The HMAC is computed over the raw request body.

```bash
# Simulating an upstream:
BODY='{"event":"push","commits":3}'
SIG=$(python -c "import hmac,hashlib; print('sha256='+hmac.new(bytes.fromhex('$SECRET'), b'$BODY', hashlib.sha256).hexdigest())")
curl -X POST http://127.0.0.1:8080/webhook/gh-push \
  -H "X-Automaton-Signature: $SIG" \
  -H "Content-Type: application/json" \
  -d "$BODY"
```

On success: a run is created with `trigger_kind = "webhook"` and the parsed body in its `trigger_payload`. On a signature mismatch or missing header: 401. On a disabled or unknown endpoint: 404.

`GET /api/webhooks` lists endpoints (without secrets) — useful for the UI and for verifying configuration.

## Python client

Agents typically want to call automaton from code, not curl. There's a thin client:

```python
from automaton.client import AutomatonClient

with AutomatonClient("http://127.0.0.1:8080", token="...") as c:
    c.register_workflow({"name": "wf", "steps": [...]})
    r = c.trigger("wf", payload={"caller": "my-agent"})
    print(c.run(r["run_id"]))
    c.signal(r["run_id"], "agent_response", payload={"answer": 42})
```

For testing webhook endpoints or for agents that *are* the upstream caller, `send_signed_webhook` signs the body and posts in one call:

```python
c.send_signed_webhook("gh-push", secret_hex, body={"event": "push"})
```

Sync only. If you need async, call from a thread.

## Retry policy

Add a `retry:` block to any step:

```yaml
- name: fetch
  type: http_get
  url: https://api.example.com/...
  retry:
    max: 3
    backoff: exponential        # or 'fixed' (default)
    initial_seconds: 2
```

Defaults: `max: 1` (no retries), `backoff: fixed`, `initial_seconds: 1.0`. A failed attempt creates a new step row with a rotated idempotency key and `ready_at = now + backoff`. Successors only enqueue when the latest attempt of every prerequisite has completed. If retries are exhausted, the run is marked failed.

The idempotency key rotates per attempt because a failed step's side effect *may or may not have landed* — the next attempt must be free to fire fresh. Honoring that contract is on each step type's author (see design doc §5).

## Logging

All daemon-loop output goes through stdlib `logging`. CLI user prints stay on stdout.

| Env var | Default | Effect |
|---|---|---|
| `AUTOMATON_LOG_LEVEL` | `INFO` | `DEBUG`, `INFO`, `WARNING`, `ERROR` |
| `AUTOMATON_LOG_FILE` | unset | path to log file (also keeps stderr) |
| `AUTOMATON_LOG_FORMAT` | `text` | `text` or `json` |

`json` mode produces one structured record per line — pipeable to a log shipper:

```json
{"ts":"2026-05-19T21:35:45.123Z","level":"info","logger":"automaton.engine","message":"leased step id=42 worker=worker-x"}
```

## What's implemented vs. what's in the design

| Design item | Status |
|---|---|
| Five-table state store + scheduler_lock + cron_trigger | Done |
| Lease/commit transaction, exactly-once observable effects | Done; proven by `tests/test_consistency.py` |
| Single-leader scheduler via lock row | Done; proven by `tests/test_scheduler.py` |
| Cron triggers (skip-on-miss) | Done |
| Inspection UI | Done — `automaton serve` |
| Backups (snapshot + Litestream) | Done — see [BACKUP.md](BACKUP.md) |
| Retry policy on step failure | Done; proven by `tests/test_retries.py` |
| External step-type plugins | Done; proven by `tests/test_plugins.py` |
| Workflow-level signals (`wait_for_signal`) | Done; proven by `tests/test_signals.py` |
| HTTP write API with bearer auth | Done |
| Pruning (delete old terminal runs) | Done; proven by `tests/test_prune.py` |
| Cancel in-flight run | Done; proven by `tests/test_cancel_and_validate.py` |
| Workflow validation at register time | Done; proven by `tests/test_cancel_and_validate.py` |
| Python client library | Done; proven by `tests/test_client.py` |
| Signed webhook receiver (per-endpoint HMAC) | Done; proven by `tests/test_webhooks.py` |
| Structured logging | Done |
| Cross-platform portability (Linux / macOS / Windows) | Done; CI matrix in `.github/workflows/test.yml`; proven by `tests/test_portability.py` |
| Schema migrations (yoyo, pre-migrate snapshot, gate) | Done — `automaton migrate`; proven by `tests/test_migrations.py` |
| TLS on the UI server (self-signed helper + HSTS) | Done — `automaton tls init` + `automaton serve --tls-cert/--tls-key`; proven by `tests/test_tls.py` |
| Mesh / remote access (Tailscale & Headscale guides + status helper) | Done — `automaton mesh status`; deploy guide in [`deploy/mesh/`](deploy/mesh/); proven by `tests/test_mesh.py` |
| Secrets management (OS keyring + `${secret:NAME}` references + redaction) | Done — `automaton secret set/get/rm/ls/import`; proven by `tests/test_secrets.py` |
| Notifications & alerting (Apprise + quiet hours + urgent override) | Done — `AUTOMATON_NOTIFY_ON_FAILURE` env hooks; `automaton notify test` self-test; proven by `tests/test_notify.py` |
| Backup, restore & DR (integrity check + Litestream guide + restore drill) | Done — `automaton restore`, [`deploy/litestream/`](deploy/litestream/), [`docs/runbooks/restore.md`](docs/runbooks/restore.md); proven by `tests/test_restore.py` |
| Timezone & DST correctness (per-trigger IANA tz, UTC storage, DST-safe) | Done — `automaton schedule add --timezone`, `automaton scheduler next`; proven by `tests/test_timezone.py` |
| Perf & scale envelope (SQLite hardening, load scripts, CI tripwires) | Done — `tests/load/`, `docs/scale.md`; proven by `tests/test_load_regression.py` |
| Workflow templates library (10 curated starters + `automaton init`) | Done — [`templates/INDEX.md`](templates/INDEX.md); proven by `tests/test_templates.py` |
| Responsive web UI + PWA shell + SSE live updates | Done — Tailwind via CDN, `/manifest.json`, `/sw.js`, `/api/run/<id>/events`; proven by `tests/test_ui.py` |
| macOS host support (launchd plists, install script, Homebrew formula) | Done — [`deploy/macos/`](deploy/macos/); proven by `tests/test_deploy_macos.py` |
| Windows host support (NSSM services, PowerShell install) | Done — [`deploy/windows/`](deploy/windows/); proven by `tests/test_deploy_windows.py` |
| Postgres backend for multi-machine workers | **Not yet**. Schema is portable. |

## Layout

```
automaton/
  __init__.py
  __main__.py        — module entrypoint
  cli.py             — argparse subcommands
  migrations/        — yoyo SQL migrations (canonical schema; 0001-initial.sql is the original schema)
  db.py              — connection + migration entry point (routes through automaton.migrate)
  migrate.py         — yoyo wrapper: shim for pre-yoyo DBs, pre-migrate snapshot, startup gate
  tls.py             — self-signed cert helper (cryptography-backed)
  mesh.py            — Tailscale/Headscale status helper (shells out to the tailscale CLI)
  secrets.py         — OS keyring wrapper + ${secret:NAME} resolver + redaction
  notify.py          — Apprise-backed run-terminal notifications (quiet hours, urgent override)
  engine.py          — register / trigger / lease / execute / commit / retry
  scheduler.py       — single-leader cron loop
  steps.py           — step type registry + entry-point plugin discovery
  ui.py              — http.server inspection UI + JSON read/write API
  backup.py          — online snapshot via SQLite's backup API
  logs.py            — structured logging setup (text or json)
  webhooks.py        — signed webhook receiver (HMAC verification)
  templating.py      — ${{ ... }} resolver for step specs
  prune.py           — delete old terminal runs and cascade rows
  client.py          — Python client (AutomatonClient) for agents
  models.py          — informational dataclasses
examples/
  hello.yaml         — two-step DAG demo
  agent_loop.yaml    — wait_for_signal pattern for human/agent in the loop
  fetch_chain.yaml   — http GET with retry → templated http POST
  retry.yaml         — shell step that fails twice then succeeds
deploy/
  README.md          — one-time setup steps for the test machine
  automaton.env.example
  systemd/           — automaton-worker, scheduler, ui units + a template variant
  mesh/              — Tailscale + Headscale deploy guide, ACL JSON, headscale config
  macos/             — launchd plists, install/uninstall script, Homebrew formula
  windows/           — NSSM-based PowerShell installer, env template, README
  litestream/        — Litestream config + setup walkthrough for off-host continuous backup
docs/
  runbooks/restore.md — three-scenario restore playbook with RTOs and verification steps
  scale.md            — operating envelope (measured throughput, when to scale out)
templates/
  INDEX.md            — categorized listing of every shipped workflow template
  <category>/<name>.yaml — backup/, health/, dev/, agent/, media/, infra/, personal/
tests/
  test_consistency.py  — exactly-once-under-crash + DAG + event log
  test_scheduler.py    — lock semantics + racing schedulers + skip-on-miss
  test_plugins.py      — entry-point discovery + isolation of broken plugins
  test_retries.py      — retry-to-success, retry-exhaustion, key rotation, successor gating
  test_signals.py      — wait_for_signal round trip + timeout + unmatched-signal isolation
  test_webhooks.py     — HMAC signing, tampering, disable, algo mismatch
  test_templating.py   — output refs, payload refs, shell step, chained data flow
  test_prune.py        — only old terminal runs deleted, dry-run, cascade
  test_client.py       — AutomatonClient round trip against the real server
  test_cancel_and_validate.py — cancel an in-flight run, validate at register time
  test_portability.py  — shell/file_append/db.connect work the same on POSIX and Windows
  test_migrations.py   — yoyo apply / idempotency / pre-yoyo shim / snapshot / gate
  test_tls.py          — cert generation + HTTPS round trip + HSTS + arg validation
  test_mesh.py         — Tailscale status parsing (mocked) + local port reachability
  test_secrets.py      — keyring round trip + ${secret:NAME} resolution + value never leaks to event log
  test_notify.py       — Apprise dispatch (mocked) + quiet hours + urgent bypass + engine end-to-end
  test_restore.py      — snapshot + integrity_check + full restore drill (delete live DB, restore, resume)
  test_timezone.py     — IANA tz validation + DST spring-forward / fall-back / preview_fires
  test_load_regression.py — CI tripwires: PRAGMAs intact + burst drain bound + long-tail starvation
  test_templates.py    — every shipped template parses + validates + has full header block
  test_ui.py           — Tailwind shell + manifest + service worker + SSE live updates + query-string token
  test_deploy_macos.py — plists parse + executables + Homebrew formula references the right runtime deps
  test_deploy_windows.py — PowerShell scripts reference each service + require admin + set auto-start + log rotation
  load/                — standalone load scripts (steady_state, burst, long_tail)
  _plugin_fixture.py   — pretend external plugin module
```

## Running the tests

```bash
pip install pytest
python -m pytest tests/
```

All 233 tests should pass in under 15 seconds. The headline ones are:
- `test_exactly_once_under_crash` — kill the worker mid-step, assert exactly-once side effect.
- `test_two_schedulers_one_run` — two scheduler threads on the same overdue trigger produce exactly one run.
- `test_retries_succeed_on_third_attempt` — failing step retries successfully and the run completes.
- `test_pre_yoyo_db_gets_shimmed` — existing installs upgrade cleanly without schema collisions.
- `test_serve_over_tls_actually_speaks_https` — TLS handshake completes against the live server with the self-signed cert.
- `test_fully_up` — mesh status helper correctly parses `tailscale status --json` into IPs, MagicDNS name, and tailnet.
- `test_secret_value_redacted_from_step_output` — a step that echoes a `${{ secret:... }}` value never persists the plaintext to the DB.
- `test_engine_fires_notification_on_run_failed` — terminal run transitions trigger an Apprise dispatch end-to-end.
- `test_restore_round_trip` — full DR drill: snapshot a running engine, delete the live DB, restore, parked workflows resume.
- `test_dst_spring_forward_skips_nonexistent_hour` — a `30 2 * * *` cron in `America/New_York` doesn't fire at the nonexistent 02:30 on transition day.
- `test_burst_drains_within_bound` — 100-run burst across 2 workers drains in <5s; catches a ~50x regression in engine overhead.
- `test_template_parses_and_validates` — every shipped template survives `engine.validate_spec`, so a schema change can't ship without updating its templates.
- `test_sse_endpoint_emits_initial_status` — `GET /api/run/<id>/events` is a live event stream; the browser drops the polling loop.
- `test_plist_runs_at_load_and_keeps_alive` — every shipped launchd plist auto-starts at login and restarts on crash (with `ThrottleInterval` to dodge tight loops).
- `test_install_depends_on_event_log` — the Windows installer registers services with a dependency on the Event Log so they don't fail at boot.

The CI matrix in `.github/workflows/test.yml` runs the full suite on
**ubuntu-latest, macos-latest, and windows-latest** against Python 3.10,
3.11, and 3.12 — nine combinations on every push and PR. Phases 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, and 13 of `PLATFORM-EXPANSION-PLAN.md` are closed.

## Schema migrations

Schema is owned by SQL files in `automaton/migrations/`, applied via
[yoyo-migrations](https://ollycope.com/software/yoyo/). To apply pending
migrations:

```bash
automaton migrate --dry-run    # report what would change
automaton migrate              # apply, with pre-migrate snapshot
```

The CLI takes a `<db>.pre-migrate-<ts>` snapshot before applying, so
rollback is a file copy. Setting `AUTOMATON_AUTO_MIGRATE=1` makes
`worker` / `scheduler` / `serve` apply pending migrations on startup; the
default (unset) is to refuse to start, so multi-host upgrades don't race.
Fresh DBs are bootstrapped automatically, and existing pre-yoyo installs
get a one-time forward-compat shim that marks `0001-initial` as applied
without re-running it.




## Remote access (mesh networking)

If you want to hit the UI from a phone on cellular or from a laptop on
someone else's Wi-Fi, the right shape is a private mesh: every device
joins a tailnet (Tailscale or self-hosted Headscale), the engine host
gets a stable `100.x.y.z` IP, and ACLs gate who can talk to it. No port
forwarding, no public internet exposure.

The full deploy guide is in [`deploy/mesh/README.md`](deploy/mesh/README.md),
including a sample [`tailscale-acl.json`](deploy/mesh/tailscale-acl.json)
and a [`headscale-config.yaml`](deploy/mesh/headscale-config.yaml). Quick
status check on the engine host:

```bash
automaton mesh status
```

Prints the Tailscale IP, MagicDNS hostname, peer count, and whether
`automaton serve` is actually listening on the expected port. Exits
non-zero if the mesh is down or the port is closed - useful in scripts.

With Tailscale Serve (`sudo tailscale serve --bg --https=443 https://localhost:8443`)
you get a real Let's Encrypt cert on `*.ts.net`, so devices don't need
to install the self-signed cert from the TLS section above.

## Time, timezones, and DST

Cron expressions interpret in UTC by default. To interpret them in
local wall-clock time of a specific zone (correctly handling DST):

```bash
automaton schedule add gh-release '30 2 * * *' --timezone America/New_York
```

`next_fire_at` is always stored as UTC in the DB; the timezone column
records how to interpret the expression. The same expression in two
zones produces two different UTC instants - so two `0 9 * * *` triggers
on `Europe/Berlin` and `America/Los_Angeles` fire 8-9 hours apart in
absolute terms, which is what you want.

Preview the next fire times for a cron expression to surface DST
surprises before they bite production:

```bash
automaton scheduler next '30 2 * * *' --timezone America/New_York --count 10
# next 10 fires of '30 2 * * *' (tz=America/New_York):
#   2026-03-09 02:30:00 EDT   (UTC: 2026-03-09 06:30:00 UTC)
#   ...
```

On the DST transition days `croniter` does the right thing: a 02:30
local fire on US/Eastern spring-forward day is skipped (that time
doesn't exist), and on fall-back day the engine fires once per
calendar day rather than twice. The `test_dst_spring_forward_skips_nonexistent_hour`
and `test_dst_fall_back_fires_once_per_day` cases in
`tests/test_timezone.py` are the regression guards.

Workflow YAMLs can declare a default `timezone:` for documentation;
the validator rejects unknown IANA names at register time:

```yaml
name: nightly_release
timezone: America/Los_Angeles
steps:
  - name: cut
    type: shell
    cmd: ["./scripts/cut.sh"]
```

(The cron trigger's own `--timezone` flag is what actually drives the
scheduler; the workflow-level field is for future workflow-default
behavior and to fail-fast on typos.)

## Backup & disaster recovery

For a single-host personal deployment, ``automaton backup`` produces a
consistent point-in-time snapshot via SQLite's online backup API:

```bash
automaton backup /var/backups/automaton/snap-$(date +%F).db
# snapshot -> /var/backups/automaton/snap-2026-05-21.db  (102400 bytes, 25 pages, 0.012s)
# integrity_check: ok
```

The ``integrity_check`` line is the early warning - silent corruption
gets caught at backup time, not at recovery time when you need the
backup to work.

For continuous off-host replication (sub-second RPO, survives host
loss), set up Litestream alongside the engine. The walkthrough +
annotated config is in [`deploy/litestream/`](deploy/litestream/);
B2, rsync.net, and MinIO are all documented.

### Restoring

```bash
automaton restore /var/backups/automaton/snap-2026-05-21.db
# restored -> /var/lib/automaton/automaton.db  (102400 bytes)
# integrity_check (source):       ok
# integrity_check (destination):  ok
# schema version:                  0001-initial
```

``automaton restore`` refuses to clobber an existing live DB (pass
``--force`` if you really mean it), runs ``PRAGMA integrity_check`` on
both source and destination, and reports the migration version on the
restored DB. If the binary expects newer migrations than what was in
the snapshot, the command warns and tells you to run
``automaton migrate`` before starting workers.

The three concrete recovery scenarios - corrupt DB, host loss,
accidental DELETE - are walked through step-by-step in
[`docs/runbooks/restore.md`](docs/runbooks/restore.md) with RTO
estimates and the exact commands.

The CI restore drill in ``tests/test_restore.py`` verifies the
end-to-end path: snapshot a live engine with parked workflows, delete
the live DB, restore, send a signal, parked runs complete cleanly. This
catches the "we had backups but never restored from them" failure mode
the plan calls out.

## Notifications

When a run finishes - successfully or not - the engine can push a
message to your phone, a chat channel, an email, anywhere
[Apprise](https://github.com/caronc/apprise) supports (110+ backends).
Configure with env vars on the engine host:

```bash
# fired on every run that transitions to 'failed'
export AUTOMATON_NOTIFY_ON_FAILURE="ntfy://your-server/automaton"

# optional: also fire on 'completed'. Off by default (would be noisy).
# export AUTOMATON_NOTIFY_ON_SUCCESS="..."

# optional: skip non-urgent notifications during sleep
export AUTOMATON_NOTIFY_QUIET_HOURS="22:00-07:00"

# verify the configuration before relying on it
automaton notify test
```

Multiple URLs go in one env var separated by spaces or newlines.
Recommended backend is a self-hosted [ntfy](https://ntfy.sh) instance
(`docker run -d -p 80:80 binwiederhier/ntfy serve`, ~30 MB RAM) - then
subscribe from the free iOS/Android apps. Apprise's URL format covers
everything from Pushover (`pover://...`) to Slack (`slack://...`) to
plain email (`mailto://...`).

Workflows can opt into "urgent" delivery (which bypasses quiet hours):

```yaml
name: nightly_backup
urgent: true          # critical - wake me up if this fails
steps:
  - name: rclone
    type: shell
    cmd: ["rclone", "sync", "/data", "b2:my-backups"]
```

The engine fires notifications fire-and-forget: if Apprise can't reach
the channel, the failure is logged at WARNING and the run state is
unaffected. ``test_engine_swallows_notify_exception`` is the regression
guard for that property.

## Secrets

API tokens, signing keys, plugin credentials - anything you don't want
in workflow YAML or env files - live in the OS keyring. The same
``automaton secret`` commands work on macOS Keychain, Windows Credential
Manager (DPAPI-backed), and Linux Secret Service:

```bash
automaton secret set GITHUB_TOKEN          # prompts for the value
automaton secret get GITHUB_TOKEN          # prints to stdout
automaton secret ls                        # names only, no values
automaton secret rm GITHUB_TOKEN
automaton secret import .env               # bulk import from a dotenv file
```

Workflows reference secrets by name with the ``${{ secret:NAME }}``
template syntax. Resolution happens at lease time, never at register
time, so the secret value never enters ``step.input_json`` (or, by
extension, the event log, backups, or the UI). If a step accidentally
echoes the value into its output, the engine redacts it before
persisting - ``test_secret_value_redacted_from_step_output`` covers
this path.

```yaml
name: gh_release
steps:
  - name: post
    type: http
    method: POST
    url: https://api.github.com/repos/me/proj/releases
    headers:
      Authorization: "Bearer ${{ secret:GITHUB_TOKEN }}"
    body:
      tag_name: v1
```

### Headless Linux

Linux's Secret Service needs a D-Bus session, which a vanilla systemd
host doesn't have. Set ``AUTOMATON_KEYRING_BACKEND=encrypted_file`` to
use the file-backed encrypted-at-rest fallback (``keyrings.alt``); pair
with ``AUTOMATON_KEYRING_PASSPHRASE`` to unlock it non-interactively.
Install the extra:

```bash
pip install -e ".[secrets-headless]"
```

For ``pass``-backed GPG storage, install ``keyring-pass`` and set the
backend env var to ``os`` - the chain will pick it up automatically.

## TLS

Generate a self-signed cert for personal-infra use:

```bash
automaton tls init --hostname automaton.local --san my-laptop.local
```

Writes `tls/cert.pem` and `tls/key.pem` in the current directory (override
with `--out-dir`). The cert covers the requested hostname plus
`localhost`, `127.0.0.1`, and `::1` by default, with `--san` for extras
(e.g. a Tailscale MagicDNS name). Validity is capped at 825 days, the
maximum Apple platforms trust for self-signed certs.

Serve over HTTPS:

```bash
automaton serve --host 0.0.0.0 --port 8443 \
    --tls-cert tls/cert.pem --tls-key tls/key.pem
```

When TLS is on, responses include `Strict-Transport-Security:
max-age=15552000` (180 days). Plain HTTP requests to the TLS port are
rejected at the socket layer. Both `--tls-cert` and `--tls-key` must be
provided together or neither - one without the other exits 1.

Each device that will hit the UI needs to trust the cert (`automaton tls
init` prints the per-OS install instructions). For multi-device or
external-internet exposure, prefer a real cert from Let's Encrypt + a
reverse proxy, or Tailscale Serve, which provisions a real cert
automatically.

## Running on macOS

automaton runs natively on macOS via launchd. The deploy artifacts in
[`deploy/macos/`](deploy/macos/) ship three plists
(`com.automaton.worker`, `com.automaton.scheduler`, `com.automaton.ui`),
an `install.sh` that copies them to `~/Library/LaunchAgents/` and
folds env values into each plist, and a Homebrew formula template for
publishing to your own tap.

```bash
pip install -e .
bash deploy/macos/install.sh
# installed: com.automaton.worker
# installed: com.automaton.scheduler
# installed: com.automaton.ui
open http://127.0.0.1:8080/
```

The file layout follows Apple conventions: DB + env file under
`~/Library/Application Support/automaton/`, logs under
`~/Library/Logs/automaton/`. Plists declare `RunAtLoad` + `KeepAlive`
with a `ThrottleInterval` of 10s so a buggy step-author doesn't spin
the CPU on a crash loop.

To refresh the env, edit the env file and re-run `install.sh` — the
script bootouts and re-bootstraps each agent with the new
`EnvironmentVariables` dict. Combined with Phases 4 (TLS), 5 (mesh),
and 11 (responsive web UI), this gets you a phone-friendly dashboard
served from your Mac over Tailscale without ever leaving a terminal
window open.

See the [full walkthrough](deploy/macos/README.md) for the Homebrew
install path, verification commands, and common gotchas.

## Running on Windows

automaton runs as three Windows services (worker, scheduler, ui) under
[NSSM](https://nssm.cc/). Install:

```powershell
# As Administrator:
Set-ExecutionPolicy -Scope Process Bypass
.\deploy\windows\install.ps1
```

`install.ps1` downloads NSSM 2.24 (~700 KB, MIT-licensed) to
`%ProgramData%\automaton\nssm\`, registers each service as
Auto-Start with a 10s `AppRestartDelay`, folds the env file's
key=value pairs into `AppEnvironmentExtra`, and starts them. Verify
with `Get-Service -Name automaton-*` or `services.msc`. Logs land in
`%ProgramData%\automaton\logs\` and rotate at 10 MB.

The DB lives at `%APPDATA%\automaton\automaton.db` (under the
service account's roaming profile). Don't put it on a network share -
SQLite's WAL doesn't support SMB.

To refresh the env: edit `%ProgramData%\automaton\automaton.env` and
re-run `install.ps1`. Uninstall with `.\deploy\windows\uninstall.ps1`
(preserves data) or `.\deploy\windows\uninstall.ps1 -Purge`
(removes everything).

See the [full walkthrough](deploy/windows/README.md) for the
Python-on-Windows install path, common AV-flags-NSSM gotcha,
LocalSystem PATH issue, and the long-paths registry tweak.

## Web UI

`automaton serve` ships a small responsive HTML UI on the same port
as the JSON API. Tailwind is loaded via CDN (no build step); the
markup uses a card layout on phones (`<sm`) and a table layout on
desktop (`>=sm`). Runs auto-refresh every 5 seconds; a run's detail
page opens a live `EventSource` to `/api/run/<id>/events` while the
run is in flight, so the status pill updates without polling.

The PWA manifest at `/manifest.json` + the one-page service worker at
`/sw.js` let the UI install to home screen on iOS Safari and Android
Chrome. Combined with Phase 5's mesh networking + Phase 4's TLS,
that's "open my phone on cellular, tap the automaton icon, see the
runs" - no native app needed.

For browser bookmarks that prefer URL params over the `Authorization`
header, GET routes accept `?token=...` as a fallback. POSTs still
require the header (anything in a URL ends up in web-server logs, so
the fallback is read-only on purpose).

The UI is a write surface too: `POST /api/trigger/<name>`,
`POST /api/run/<id>/cancel`, and `POST /api/signals/<run_id>/<name>`
all live on the same port with bearer-token auth. See the HTTP API
section above for the full list.

## Workflow templates

Ten curated starters under [`templates/`](templates/INDEX.md) covering
the workflows people set up first: home-folder backup to B2,
website-up + cert-expiry health checks, git mirroring, docker prune,
the Claude agent-loop pattern, photo import off an SD card, certbot
renewal, log rotation, and a morning RSS brief.

```bash
automaton init --list                               # browse the catalog
automaton init my-backup --template backup/home-folder
# wrote my-backup.yaml
# required secrets: B2_KEY_ID, B2_APP_KEY
# suggested cron: every day at 03:15 local
#
# next: edit my-backup.yaml to fill in payload defaults, then:
#   automaton register my-backup.yaml
```

Each template ships with a comment block (title, description, required
secrets/env, suggested cron, last-verified date) that `automaton init`
prints and that `templates/INDEX.md` is generated from. CI parses
every template through `engine.validate_spec` on every PR via
`test_template_parses_and_validates`, so a schema change can't ship
without bringing its templates along.

## Scale envelope

Measured numbers and the recommended cutoff for moving to Postgres
live in [`docs/scale.md`](docs/scale.md). The headline: a single
host comfortably sustains hundreds of noop runs/sec, burst-drains
1000 runs through 4 workers in <1s, and short steps don't starve
when concurrent 1-second steps are in flight. Past ~500 runs/sec
sustained, write contention on the single SQLite writer becomes the
bottleneck and Phase 16 (Postgres) starts to be the right answer.

The CI suite includes lightweight tripwires
(`tests/test_load_regression.py`) that catch a ~5x slowdown on every
PR without flaking on slow runners; the full operating-envelope
measurements come from running the scripts in `tests/load/` on real
hardware:

```bash
python -m tests.load.burst --count 1000 --workers 4
python -m tests.load.steady_state --rate 100 --workers 4 --seconds 30
python -m tests.load.long_tail --short 50 --long 5 --workers 4
```

The production SQLite PRAGMAs (`WAL`, `synchronous=NORMAL`,
`busy_timeout=30000`, `wal_autocheckpoint=1000`) are set by
`db.connect()` and asserted by `verify_pragmas()`; the test
`test_pragmas_match_production_defaults` is the regression guard.

## Limitations to know about

- **One host.** SQLite WAL handles many readers and one writer per database. Multiple worker *processes* on the same host work fine. Multiple hosts mean Postgres.
- **`automaton serve` binds to localhost by default.** Set `AUTOMATON_TOKEN` and put a TLS-terminating reverse proxy in front before going public. Never combine `--host 0.0.0.0` with `--insecure-no-auth`.
- **Step authors own idempotency.** The engine refuses to be lied to — it won't pretend retries are safe. New step types must explicitly honor the idempotency key.
- **Editing a workflow YAML does nothing until re-registered.** New versions auto-bump; in-flight runs pin to the version they started with.
